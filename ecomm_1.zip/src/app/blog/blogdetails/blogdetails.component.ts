import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogdetails',
  templateUrl: './blogdetails.component.html',
  styleUrls: ['./blogdetails.component.css']
})
export class BlogdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

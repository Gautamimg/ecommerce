import { CustompipesPipe } from './custompipes.pipe';

describe('CustompipesPipe', () => {
  it('create an instance', () => {
    const pipe = new CustompipesPipe();
    expect(pipe).toBeTruthy();
  });
});

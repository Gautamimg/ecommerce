import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageorder',
  templateUrl: './manageorder.component.html',
  styleUrls: ['./manageorder.component.css']
})
export class ManageorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

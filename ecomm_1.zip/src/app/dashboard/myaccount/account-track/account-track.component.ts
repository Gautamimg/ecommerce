import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-track',
  templateUrl: './account-track.component.html',
  styleUrls: ['./account-track.component.css']
})
export class AccountTrackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

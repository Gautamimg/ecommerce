import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogmasonry',
  templateUrl: './blogmasonry.component.html',
  styleUrls: ['./blogmasonry.component.css']
})
export class BlogmasonryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

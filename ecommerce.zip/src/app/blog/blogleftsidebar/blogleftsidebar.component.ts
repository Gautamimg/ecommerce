import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogleftsidebar',
  templateUrl: './blogleftsidebar.component.html',
  styleUrls: ['./blogleftsidebar.component.css']
})
export class BlogleftsidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editaddressbook',
  templateUrl: './editaddressbook.component.html',
  styleUrls: ['./editaddressbook.component.css']
})
export class EditaddressbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

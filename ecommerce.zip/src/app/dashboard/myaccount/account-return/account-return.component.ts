import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-return',
  templateUrl: './account-return.component.html',
  styleUrls: ['./account-return.component.css']
})
export class AccountReturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

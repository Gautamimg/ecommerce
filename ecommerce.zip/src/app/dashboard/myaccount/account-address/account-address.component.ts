import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-address',
  templateUrl: './account-address.component.html',
  styleUrls: ['./account-address.component.css']
})
export class AccountAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

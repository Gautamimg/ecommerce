import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-orders',
  templateUrl: './account-orders.component.html',
  styleUrls: ['./account-orders.component.css']
})
export class AccountOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-payment',
  templateUrl: './account-payment.component.html',
  styleUrls: ['./account-payment.component.css']
})
export class AccountPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

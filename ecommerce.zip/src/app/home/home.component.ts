import { Component, OnInit } from '@angular/core';
declare var $:any;
import {ServicesService} from '../services.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  top_rated: any;
  child_data:any=[];
  child_data_div:boolean=false;
  child_data_1:any;
  child_data_1_div:boolean=false;
  parent_div:boolean=true;
  constructor(private serve:ServicesService) { }

  ngOnInit(): void {
    $('#addtocart').hide();
    $('.owl-carousel').owlCarousel({
      loop: true,
      nav: true,
      autoplay: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 1
        },
        1000: {
          items: 1
        }
      }
    })
  
    this.serve.get('/categorylist').subscribe((res:any)=>{
      this.top_rated=res.result;
      console.log(res);
    })
  }
  aLL_div(){
    $('#parent_div').show();
    $('#child_1').hide()
    $('#child_2').hide()
  this.parent_div=true;
  }
  categry(id:any){
    $('#parent_div').hide();
    $('#child_1').show()
    $('#child_2').hide()
    this.child_data=this.top_rated[id].child;
    console.log(this.child_data);
  }
  get_id(id:any){
    this.parent_div=false;
    $('#child_1').show()
    $('#parent_div').hide();
    // $('#child_2').show()
    this.child_data=this.top_rated[id].child;
    console.log(this.child_data);
  }
  get_id_1(id:any){
  $('#child_1').hide()
  $('#child_2').show()
  this.child_data_1=this.child_data[id].child
  console.log(this.child_data_1);
  }
  }

